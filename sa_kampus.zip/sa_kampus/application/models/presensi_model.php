<?php
class Presensi_model extends CI_Model{

    public function tampil_data($table)
    {
        return $this->db->get($table);
    }

    public function insert_data($data,$table)
    {
        $this->db->insert($table,$data);
    }
    
    public function edit_data($where,$table)
    {
        return $this->db->get_where($table,$where);
    }

    public function update_data($where,$data,$table)
    {
        $this->db->where($where);
        $this->db->update($table,$data);
    }

    public function hapus_data($where,$table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }

    public $table = 'presensi';
    public $id = 'id_presensi';

    public function get_data_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }

    public function getAllPresensi()
    {
        $this->db->select('p.id_presensi, m.nama_lengkap, p.tanggal_presensi, p.status_presensi');
        $this->db->from($this->table . ' p');
        $this->db->join('mahasiswa m', 'm.id = p.id_mahasiswa');
        $this->db->order_by('p.tanggal_presensi', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }
    
}