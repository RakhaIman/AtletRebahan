<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Universitas Atlet Rebahan</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
        }
        .hero-section {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            padding: 100px 0;
            text-align: center;
        }
        .card-hover:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 20px rgba(0,0,0,0.12);
            transition: all 0.3s ease;
        }
        .section-header {
            color: #2575fc;
            margin-bottom: 30px;
            font-weight: bold;
        }
        .footer {
            background-color: #333;
            color: white;
            padding: 20px 0;
        }

        .lecturer-card {
        transition: all 0.3s ease;
        overflow: hidden;
        border: none;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    .lecturer-image-container {
        position: relative;
        overflow: hidden;
    }

    .lecturer-image {
        width: 100%;
        height: 300px;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .lecturer-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(37, 117, 252, 0.8);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .lecturer-card:hover .lecturer-overlay {
        opacity: 1;
    }

    .lecturer-card:hover .lecturer-image {
        transform: scale(1.1);
    }

    .lecturer-details {
        text-align: center;
    }

    .lecturer-expertise {
        margin-top: 10px;
    }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-graduation-cap"></i> Universitas Atlet Rebahan
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#about">Tentang Kampus</a></li>
                    <li class="nav-item"><a class="nav-link" href="#identitas">Identitas</a></li>
                    <li class="nav-item"><a class="nav-link" href="#informasi">Informasi</a></li>
                    <li class="nav-item"><a class="nav-link" href="#dosen">Dosen</a></li>
                    <li class="nav-item"><a class="nav-link" href="#jadwal">Jadwal</a></li>
                    <li class="nav-item"><a class="nav-link" href="#jurusan">Jurusan</a></li>
                    <li class="nav-item"><a class="nav-link" href="#prodi">Program Studi</a></li>
                    <li class="nav-item"><a class="nav-link" href="#mahasiswa">Mahasiswa</a></li>
                    <li class="nav-item"><a class="nav-link" href="#kontak">Kontak</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <h1 class="display-4">Selamat Datang di Universitas Atlet Rebahan</h1>
            <p class="lead">Tempat di mana Bakat dan Prestasi Bertemu</p>
            <a href="#about" class="btn btn-light btn-lg mt-3">Pelajari Lebih Lanjut</a>
        </div>
    </div>

    <!-- About Section -->
    <section id="about" class="container my-5">
        <h2 class="text-center section-header">Tentang Kampus</h2>
        <div class="row">
            <div class="col-md-8 offset-md-2 text-center">
                <p>Universitas Atlet Rebahan adalah institusi pendidikan tinggi yang berdedikasi untuk mengembangkan potensi mahasiswa dalam bidang olahraga dan akademik.</p>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#aboutModal">
                    Selengkapnya
                </button>
            </div>
        </div>
    </section>

    <!-- Identitas Section -->
    <section id="identitas" class="container my-5">
        <h2 class="text-center section-header">Identitas Kampus</h2>
        <div class="row">
            <?php if (!empty($identitas)): foreach ($identitas as $id): ?>
                <div class="col-md-6 offset-md-3">
                    <div class="card card-hover">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-university"></i> Detail Identitas</h5>
                            <p><strong>Nama:</strong> <?php echo $id->nama_website; ?></p>
                            <p><strong>Alamat:</strong> <?php echo $id->alamat; ?></p>
                            <p><strong>Email:</strong> <?php echo $id->email; ?></p>
                            <p><strong>Telepon:</strong> <?php echo $id->telepon; ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; else: ?>
                <p class="text-center">Tidak ada data identitas.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Identitas Section -->
    <section id="informasi" class="container my-5">
        <h2 class="text-center section-header">Informasi Kampus</h2>
        <div class="row">
            <?php if (!empty($informasi)): foreach ($informasi as $info): ?>
                <div class="col-md-4 mb-4">
                    <div class="card card-hover">
                        <div class="card-body">
                            <h5 class="card-title"><i class="<?php echo $info->icon; ?>"></i> Detail Informasi</h5>
                            <p><strong>Judul:</strong> <?php echo $info->judul_informasi; ?></p>
                            <p><strong>Isi Informasi:</strong> <?php echo $info->isi_informasi; ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; else: ?>
                <p class="text-center">Tidak ada data informasi.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Dosen Section -->
    <!-- Dosen Section with Enhanced Design -->
<section id="dosen" class="container my-5">
    <h2 class="text-center section-header">Tim Dosen Kami</h2>
    <div class="row">
        <?php if (!empty($dosen)): foreach ($dosen as $dos): ?>
            <div class="col-md-4 mb-4">
                <div class="card card-hover lecturer-card">
                    <div class="lecturer-image-container">
                        <img src="<?php echo base_url('assets/uploads/' . $dos->foto); ?>" 
                             class="card-img-top lecturer-image" 
                             alt="<?php echo $dos->nama_dosen; ?>">
                        <div class="lecturer-overlay">
                            <div class="lecturer-details">
                                <h5><?php echo $dos->nama_dosen; ?></h5>
                                <p><?php echo $dos->nidn; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-body text-center">
                        <h5 class="card-title"><?php echo $dos->nama_dosen; ?></h5>
                        <p class="card-text text-muted">
                            <i class="fas fa-id-badge me-2"></i><?php echo $dos->nidn; ?>
                        </p>
                        <?php if (!empty($dos->keahlian)): ?>
                            <div class="lecturer-expertise">
                                <span class="badge bg-primary">
                                    <i class="fas fa-graduation-cap me-1"></i>
                                    <?php echo $dos->keahlian; ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; else: ?>
            <p class="text-center">Belum ada data dosen.</p>
        <?php endif; ?>
    </div>
</section>

    <!-- Jadwal Kuliah Section -->
    <section id="jadwal" class="container my-5">
        <h2 class="text-center section-header">Jadwal Kuliah</h2>
        <div class="row">
            <?php if (!empty($jadwal_kuliah)): foreach ($jadwal_kuliah as $jadwal): ?>
                <div class="col-md-4 mb-4">
                    <div class="card card-hover">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-book"></i> <?php echo $jadwal->kode_matkul; ?></h5>
                            <p><i class="fas fa-calendar"></i> Hari: <?php echo $jadwal->hari; ?></p>
                            <p><i class="fas fa-clock"></i> Jam: <?php echo $jadwal->jam_mulai; ?> - <?php echo $jadwal->jam_selesai; ?></p>
                            <p><i class="fas fa-map-marker-alt"></i> Ruang: <?php echo $jadwal->ruangan; ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; else: ?>
                <p class="text-center">Belum ada jadwal kuliah.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Jurusan Kuliah Section -->
    <section id="jurusan" class="container my-5">
        <h2 class="text-center section-header">Jurusan</h2>
        <div class="row">
            <?php if (!empty($jurusan)): foreach ($jurusan as $jrs): ?>
                <div class="col-md-4 mb-4">
                    <div class="card card-hover">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-university"></i> <?php echo $jrs->nama_jurusan; ?></h5>
                            <p>Kode Jurusan : <?php echo $jrs->kode_jurusan; ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; else: ?>
                <p class="text-center">Belum ada jadwal kuliah.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Prodi Kuliah Section -->
    <section id="prodi" class="container my-5">
        <h2 class="text-center section-header">Program Studi</h2>
        <div class="row">
            <?php if (!empty($prodi)): foreach ($prodi as $prd): ?>
                <div class="col-md-4 mb-4">
                    <div class="card card-hover">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-university"></i> <?php echo $prd->nama_prodi; ?></h5>
                            <p>Kode Prodi : <?php echo $prd->kode_prodi; ?></p>
                            <p>Jurusan : <?php echo $prd->nama_jurusan; ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; else: ?>
                <p class="text-center">Belum ada jadwal kuliah.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Mahasiswa Section -->
    <section id="mahasiswa" class="container my-5">
        <h2 class="text-center section-header">Data Mahasiswa</h2>
        <div class="row">
            <?php if (!empty($mahasiswa)): foreach ($mahasiswa as $mhs): ?>
                <div class="col-md-4 mb-4">
                    <div class="card card-hover">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-user-graduate"></i> <?php echo $mhs->nama_lengkap; ?></h5>
                            <p><strong>NIM:</strong> <?php echo $mhs->nim; ?></p>
                            <p><strong>Program Studi:</strong> <?php echo $mhs->nama_prodi; ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; else: ?>
                <p class="text-center">Tidak ada data mahasiswa.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer id="kontak" class="footer text-center">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h4>Hubungi Kami</h4>
                    <p>Email: atletrebahan@university.com</p>
                    <div class="social-links mt-3">
                        <a href="#" class="text-white mx-2"><i class="fab fa-facebook fa-2x"></i></a>
                        <a href="#" class="text-white mx-2"><i class="fab fa-twitter fa-2x"></i></a>
                        <a href="#" class="text-white mx-2"><i class="fab fa-instagram fa-2x"></i></a>
                    </div>
                </div>
            </div>
            <p class="mt-3">&copy; 2024 Universitas Atlet Rebahan. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- About Modal -->
    <div class="modal fade" id="aboutModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Tentang Kampus</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <h6>Sejarah</h6>
                    <?php if (!empty($tentang)): foreach ($tentang as $ttg) : echo $ttg->sejarah; endforeach; else: echo "Informasi tidak tersedia."; endif; ?>
                    
                    <h6 class="mt-3">Visi</h6>
                    <?php if (!empty($tentang)): foreach ($tentang as $ttg) : echo $ttg->visi; endforeach; else: echo "Informasi tidak tersedia."; endif; ?>
                    
                    <h6 class="mt-3">Misi</h6>
                    <?php if (!empty($tentang)): foreach ($tentang as $ttg) : echo $ttg->misi; endforeach; else: echo "Informasi tidak tersedia."; endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS and Popper -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
</body>
</html>