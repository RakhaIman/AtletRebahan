<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-lock"></i> Login Mahasiswa
    </div>

    <?php echo form_open('login/cek_login'); ?>

    <div class="form-group">
        <label for="nim">NIM</label>
        <input type="text" name="nim" id="nim" class="form-control" required>
        <?php echo form_error('nim', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="password">Password</label>
        <input type="password" name="password" id="password" class="form-control" required>
        <?php echo form_error('password', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <button type="submit" class="btn btn-primary">Login</button>

    <?php echo form_close(); ?>

    <?php if ($this->session->flashdata('error')) : ?>
        <div class="alert alert-danger" role="alert">
            <?php echo $this->session->flashdata('error'); ?>
        </div>
    <?php endif; ?>

</div>