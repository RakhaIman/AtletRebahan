<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-calendar-alt"></i> Tambah Tahun Akademik
    </div>

    <form method="post" action="<?php echo base_url('admin/tahun_akademik/aksi_tambah_tahun') ?>">
        <div class="form-group">
            <label>Tahun Akademik</label>
            <input type="text" name="tahun_akademik" placeholder="Contoh : 2025/2026" class="form-control">
            <?php echo form_error('tahun_akademik', '<div class="text-danger small" ml-3>') ?>
        </div>
        <div class="form-group">
            <label>Semester</label>
            <select name="semester" class="form-control">
                <option value="">--Pilih Semester--</option>
                <option value="ganjil">Ganjil</option>
                <option value="genap">Genap</option>
            </select>
        </div>
        <div class="form-group">
            <label>Status Mahasiswa</label>
            <select name="status" class="form-control">
                <option value="">--Pilih Status--</option>
                <option>Aktif</option>
                <option>Nonaktif</option>
            </select>
        </div>
        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
            <?php echo anchor('admin/tahun_akademik', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
        </div>
    </form>
</div>