<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Form Input Jurusan
    </div>

    <form method="post" action="<?php echo base_url('admin/jurusan/aksi_input') ?>">
        <div class="form-group">
            <label>Kode Jurusan</label>
            <input type="text" name="kode_jurusan" placeholder="masukkan kode jurusan" class="form-control">
            <?php echo form_error('kode_jurusan', '<div class="text-danger small" ml-3>') ?>
        </div>
        <div class="form-group">
            <label>Nama Jurusan</label>
            <input type="text" name="nama_jurusan" placeholder="masukkan nama jurusan" class="form-control">
            <?php echo form_error('nama_jurusan', '<div class="text-danger small" ml-3>') ?>
        </div>

        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
            <?php echo anchor('admin/jurusan', '<div class="btn btn-danger btn-sm"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
        </div>
    </form>
</div>