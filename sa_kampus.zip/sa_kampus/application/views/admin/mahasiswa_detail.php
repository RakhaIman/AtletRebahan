<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-eye"></i> Detail Mahasiswa
    </div>

    <div class="d-flex align-items-start">
        <?php foreach ($detail as $dt) : ?>
        <!-- Gambar di sebelah kiri -->
        <img src="<?php echo base_url('assets/uploads/').$dt->foto ?>" class="img-thumbnail" style="width: 150px; height: auto; margin-right: 20px;">
        <?php endforeach; ?>
        
        <!-- Tabel di sebelah kanan -->
        <table class="table table-bordered table-striped table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>Informasi</th>
                    <th>Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($detail as $dt) : ?>
                    <tr>
                        <td>NIM</td>
                        <td><?php echo $dt->nim; ?></td>
                    </tr>
                    <tr>
                        <td>Nama Lengkap</td>
                        <td><?php echo $dt->nama_lengkap; ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?php echo $dt->alamat; ?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><?php echo $dt->email; ?></td>
                    </tr>
                    <tr>
                        <td>Telepon</td>
                        <td><?php echo $dt->telepon; ?></td>
                    </tr>
                    <tr>
                        <td>Tempat Lahir</td>
                        <td><?php echo $dt->tempat_lahir; ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Lahir</td>
                        <td><?php echo $dt->tanggal_lahir; ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td><?php echo $dt->jenis_kelamin; ?></td>
                    </tr>
                    <tr>
                        <td>Program Studi</td>
                        <td><?php echo $dt->nama_prodi; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Tombol Kembali di bawah tabel -->
    <div class="text-center" style="margin-top: 20px;">
    <?php echo anchor('admin/mahasiswa', '<div class="btn btn-danger btn-lg">Kembali</div>'); ?>
    </div>
</div>