<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Form Input Prodi
    </div>

    <form method="post" action="<?php echo base_url('admin/prodi/aksi_tambah_prodi') ?>">
        <div class="form-group">
            <label>Kode Prodi</label>
            <input type="text" name="kode_prodi" placeholder="masukkan kode prodi" class="form-control">
            <?php echo form_error('kode_prodi', '<div class="text-danger small" ml-3>') ?>
        </div>
        <div class="form-group">
            <label>Nama Prodi</label>
            <input type="text" name="nama_prodi" placeholder="masukkan nama prodi" class="form-control">
            <?php echo form_error('nama_prodi', '<div class="text-danger small" ml-3>') ?>
        </div>
        <div class="form-group">
            <label>Nama Jurusan</label>
            <select name="nama_jurusan" class="form-control">
                <option value="">--Pilih Jurusan--</option>
                <?php foreach ($jurusan as $jrs) : ?>
                    <option value="<?php echo $jrs->nama_jurusan ?>"><?php echo $jrs->nama_jurusan ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
            <?php echo anchor('admin/prodi', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
        </div>
    </form>
</div>