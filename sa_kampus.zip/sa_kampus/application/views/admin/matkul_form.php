<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Form Input Matakuliah
    </div>

    <form method="post" action="<?php echo base_url('admin/matkul/aksi_tambah_matkul') ?>">
        <div class="form-group">
            <label>Kode Matakuliah</label>
            <input type="text" name="kode_matkul" placeholder="Masukkan kode matakulah" class="form-control">
            <?php echo form_error('kode_matkul', '<div class="text-danger small" ml-3>') ?>
        </div>
        <div class="form-group">
            <label>Nama Matakulah</label>
            <input type="text" name="nama_matkul" placeholder="Masukkan nama matakuliah" class="form-control">
            <?php echo form_error('nama_matkul', '<div class="text-danger small" ml-3>') ?>
        </div>
        <div class="form-group">
            <label>SKS</label>
            <select name="sks" class="form-control">
                <option>2</option>
                <option>4</option>
            </select>
        </div>
        <div class="form-group">
            <label>Semester</label>
            <select name="semester" class="form-control">
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
                <option>7</option>
                <option>8</option>
            </select>
        </div>
        <div class="form-group">
            <label>Program Studi</label>
            <select name="nama_prodi" class="form-control">
                <option value="">--Pilih Program Studi--</option>
                <?php foreach ($prodi as $prd) : ?>
                    <option value="<?php echo $prd->nama_prodi ?>"><?php echo $prd->nama_prodi ?></option>
                <?php endforeach; ?>
            </select>
        </div>


        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
            <?php echo anchor('admin/matkul', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
        </div>
    </form>
</div>