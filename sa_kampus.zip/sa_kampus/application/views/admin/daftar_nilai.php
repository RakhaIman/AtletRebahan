<?php

$nilai = get_instance();
$nilai->load->model('krs_model');
$nilai->load->model('mahasiswa_model');
$nilai->load->model('matkul_model');
$nilai->load->model('ta_model');

$krs = $nilai->krs_model->get_data_by_id($id_krs[0]);
$kode_matkul = $krs->kode_matkul;
$id_ta = $krs->id_ta;
?>

<div class="container-fluid">
    <div class="alert alert-success">
        <i class="fas fa-university"></i> Daftar Nilai Mahasiswa
    </div>

    <center>
        <legend><strong>Daftar Nilai Mahasiswa</strong></legend>
        <table>
            <tr>
                <td>Kode Matakuliah</td>
                <td>: <?php echo $kode_matkul; ?></td>
            </tr>
            <tr>
                <td>Nama Matakuliah</td>
                <td>: <?php echo $nilai->matkul_model->get_data_by_id($kode_matkul)->nama_matkul; ?></td>
            </tr>
            <tr>
                <td>SKS</td>
                <td>: <?php echo $nilai->matkul_model->get_data_by_id($kode_matkul)->sks; ?></td>
            </tr>
                <?php 
                    $thn = $nilai->ta_model->get_data_by_id($id_ta);
                    $semester = $thn->semester == 'Ganjil';

                    if($semester){
                        $tampilSemester = "Ganjil";
                    }else{
                        $tampilSemester = "Genap";
                    }
                ?>
            <tr>
                <td>Tahun Akademik (semester)</td>
                <td>: <?php echo $thn->tahun_akademik."(".$tampilSemester.")" ?></td>
            </tr>
        </table>
    </center>

    <table class="table table-bordered table-striped table-hover mt-3">
        <tr>
            <th>No</th>
            <th>NIM</th>
            <th>Nama Lengkap</th>
            <th>Nilai</th>
        </tr>

        <?php
            $no = 1;
            for($i=0;$i<sizeof($id_krs); $i++)
            {
        ?>
        <tr>
            <td><?php echo $no++ ?></td>
            <?php $nim = $nilai->krs_model->get_data_by_id($id_krs[$i])->nim ?>
            <td><?php echo $nim; ?></td>
            <td><?php echo $nilai->mahasiswa_model->get_data_by_id($nim)->nama_lengkap; ?></td>
            <td><?php echo $nilai->krs_model->get_data_by_id($id_krs[$i])->nilai; ?></td>
        </tr>
        <?php } ?>
    </table>
</div>