<div class="container-fluid">

<div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Form Tambah User
    </div>

    <form method="post" action="<?php echo base_url('admin/user/aksi_tambah_user') ?>">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="Masukkan username" class="form-control">
            <?php echo form_error('username', '<div class="text-danger small" ml-3>') ?>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="text" name="password" placeholder="Masukkan password" class="form-control">
            <?php echo form_error('password', '<div class="text-danger small" ml-3>') ?>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="text" name="email" placeholder="Masukkan email" class="form-control">
            <?php echo form_error('email', '<div class="text-danger small" ml-3>') ?>
        </div>
        <div class="form-group">
            <label>Level</label>
            <select name="level" class="form-control">
                <?php 
                if($level == 'admin'){
                    echo '<option value="admin">Admin</option>';
                
                ?>
                <option value="admin" selected>Admin</option>
                <option value="mahasiswa">Mahasiswa</option>

                <?php 
                }elseif ($level == 'mahasiswa'){
                ?>

                <option value="admin" >Admin</option>
                <option value="mahasiswa" selected>Mahasiswa</option>

                <?php 
                }else{
                ?>

                <option value="admin" >Admin</option>
                <option value="mahasiswa">Mahasiswa</option>

                <?php 
                }
                ?>
            </select>
            <?php echo form_error('level', '<div class="text-danger small" ml-3>') ?>
        </div>

        <div class="form-group">
            <label>Blokir</label>
            <select name="blokir" class="form-control">
                <?php 
                    if($blokir == 'Y'){
                ?>
                    <option value="Y" selected>Admin</option>
                    <option value="N">Mahasiswa</option>
                
                <?php 
                }elseif ($blokir == 'N'){
                 ?>

                <option value="Y" >Ya</option>
                <option value="N" selected>Tidak</option>

                <?php 
                }else{
                ?>

                <option value="Y">Ya</option>
                <option value="N">Tidak</option>

                <?php } ?>

            </select>
            <?php echo form_error('blokir', '<div class="text-danger small" ml-3>') ?>
        </div>


        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
            <?php echo anchor('admin/user', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
        </div>
    </form>
</div>