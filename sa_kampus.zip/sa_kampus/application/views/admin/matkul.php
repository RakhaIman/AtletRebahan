<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Matakuliah
    </div>

    <?php echo $this->session->flashdata('pesan') ?>

    <?php echo anchor('admin/matkul/tambah_matkul', '<button class="btn btn-sm btn-primary 
        mb-3"><i class="fas fa-plus fa-sm"></i> Tambah Prodi</button>') ?>

    <table class="table table-bordered table-striped table-hover">
        <tr>
            <th>No</th>
            <th>Kode Matakuliah</th>
            <th>Nama Matakuliah</th>
            <th>Program Studi</th>
            <th colspan="3">Aksi</th>
        </tr>
        <?php $no = 1; foreach ($matkul as $mk) :  ?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $mk->kode_matkul ?></td>
                <td><?php echo $mk->nama_matkul ?></td>
                <td><?php echo $mk->nama_prodi ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/matkul/detail/' . $mk->kode_matkul,
                                        '<div class="btn btn-sm btn-info"><i class="fa fa-eye"></div>'
                                    ) ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/matkul/update/' . $mk->kode_matkul,
                                        '<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></div>'
                                    ) ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/matkul/delete/' . $mk->kode_matkul,
                                        '<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></div>'
                                    ) ?></td>
            </tr>
            <?php endforeach; ?>
    </table>
</div>