<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-eye"></i> Detail Mahasiswa
    </div>

    <div class="d-flex align-items-start">
        <?php foreach ($detail as $dt) : ?>
        <!-- Gambar di sebelah kiri -->
        <img src="<?php echo base_url('assets/uploads/').$dt->foto ?>" class="img-thumbnail" style="width: 150px; height: auto; margin-right: 20px;">
        <?php endforeach; ?>
        
        <!-- Tabel di sebelah kanan -->
        <table class="table table-bordered table-striped table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>Informasi</th>
                    <th>Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($detail as $dt) : ?>
                    <tr>
                        <td>NIDN</td>
                        <td><?php echo $dt->nidn; ?></td>
                    </tr>
                    <tr>
                        <td>Nama Dosen</td>
                        <td><?php echo $dt->nama_dosen; ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?php echo $dt->alamat; ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td><?php echo $dt->jenis_kelamin; ?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><?php echo $dt->email; ?></td>
                    </tr>
                    <tr>
                        <td>Nomor Telepon</td>
                        <td><?php echo $dt->telepon; ?></td>
                    </tr>
                    
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Tombol Kembali di bawah tabel -->
    <div class="text-center" style="margin-top: 20px;">
    <?php echo anchor('admin/dosen', '<div class="btn btn-danger btn-lg">Kembali</div>'); ?>
    </div>
</div>