<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-calendar-alt"></i> Detail Jadwal Kuliah
    </div>

    <div class="card">
        <div class="card-header">
            Detail Jadwal Kuliah
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped table-hover">
              <?php foreach ($detail as $dt) : ?>
                <tr>
                    <th>Kode Mata Kuliah</th>
                    <td><?php echo $dt->kode_matkul; ?></td>
                </tr>
                <tr>
                    <th>Nama Dosen</th>
                    <td><?php echo $dt->nama_dosen; ?></td>
                </tr>
                <tr>
                    <th>Hari</th>
                    <td><?php echo $dt->hari; ?></td>
                </tr>
                <tr>
                    <th>Jam Mulai</th>
                    <td><?php echo $dt->jam_mulai; ?></td>
                </tr>
                <tr>
                    <th>Jam Selesai</th>
                    <td><?php echo $dt->jam_selesai; ?></td>
                </tr>
                <tr>
                    <th>Ruangan</th>
                    <td><?php echo $dt->ruangan; ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <div class="card-footer">
            <?php echo anchor('admin/jadwal_kuliah', '<button class="btn btn-sm btn-primary">Kembali</button>'); ?>
        </div>
    </div>

</div>