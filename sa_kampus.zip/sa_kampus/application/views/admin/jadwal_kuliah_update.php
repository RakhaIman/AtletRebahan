<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-calendar-alt"></i> Form Edit Jadwal Kuliah
    </div>

    <?php echo form_open_multipart('admin/jadwal_kuliah/aksi_update_jadwal'); ?>

    <input type="hidden" name="id" value="<?php echo $jadwal->id; ?>">

    <div class="form-group">
        <label for="kode_matkul">Kode Mata Kuliah</label>
        <input type="text" name="kode_matkul" id="kode_matkul" class="form-control" value="<?php echo $jadwal->kode_matkul; ?>" required>
        <?php echo form_error('kode_matkul', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="nama_dosen">Nama Dosen</label>
        <select name="nama_dosen" id="nama_dosen" class="form-control" required>
            <option value="">-- Pilih Dosen --</option>
            <?php foreach ($dosen as $dsn) : ?>
                <option value="<?php echo $dsn->nama_dosen ?>" <?php if ($dsn->nama_dosen == $jadwal->nama_dosen) echo 'selected'; ?>><?php echo $dsn->nama_dosen ?></option>
            <?php endforeach; ?>
        </select>
        <?php echo form_error('nama_dosen', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="hari">Hari</label>
        <select name="hari" id="hari" class="form-control" required>
            <option value="">-- Pilih Hari --</option>
            <option value="Senin" <?php if ($jadwal->hari == 'Senin') echo 'selected'; ?>>Senin</option>
            <option value="Selasa" <?php if ($jadwal->hari == 'Selasa') echo 'selected'; ?>>Selasa</option>
            <option value="Rabu" <?php if ($jadwal->hari == 'Rabu') echo 'selected'; ?>>Rabu</option>
            <option value="Kamis" <?php if ($jadwal->hari == 'Kamis') echo 'selected'; ?>>Kamis</option>
            <option value="Jumat" <?php if ($jadwal->hari == 'Jumat') echo 'selected'; ?>>Jumat</option>
            <option value="Sabtu" <?php if ($jadwal->hari == 'Sabtu') echo 'selected'; ?>>Sabtu</option>
            <option value="Minggu" <?php if ($jadwal->hari == 'Minggu') echo 'selected'; ?>>Minggu</option>
        </select>
        <?php echo form_error('hari', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="jam_mulai">Jam Mulai</label>
        <input type="time" name="jam_mulai" id="jam_mulai" class="form-control" value="<?php echo $jadwal->jam_mulai; ?>" required>
        <?php echo form_error('jam_mulai', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="jam_selesai">Jam Selesai</label>
        <input type="time" name="jam_selesai" id="jam_selesai" class="form-control" value="<?php echo $jadwal->jam_selesai; ?>" required>
        <?php echo form_error('jam_selesai', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="ruangan">Ruangan</label>
        <input type="text" name="ruangan" id="ruangan" class="form-control" value="<?php echo $jadwal->ruangan; ?>" required>
        <?php echo form_error('ruangan', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <button type="submit" class="btn btn-primary">Simpan</button>
    <button type="reset" class="btn btn-danger">Reset</button>

    <?php echo form_close(); ?>

</div>