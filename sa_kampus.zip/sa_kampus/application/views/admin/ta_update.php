<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-calendar-alt"></i> Tambah Tahun Akademik
    </div>
    <?php foreach($tahun_akademik as $ta) : ?>

    <form method="post" action="<?php echo base_url('admin/tahun_akademik/aksi_update') ?>">
        <div class="form-group">
            <label>Tahun Akademik</label>
            <input type="hidden" name="id_ta" class="form-control" value="<?php echo $ta->id_ta ?>" required>
            <input type="text" name="tahun_akademik" placeholder="Contoh : 2025/2026" class="form-control" value="<?php echo $ta->tahun_akademik ?>" required>
            <?php echo form_error('tahun_akademik', '<div class="text-danger small" ml-3>') ?>
        </div>
        <div class="form-group">
            <label>Semester</label>
            <select name="semester" class="form-control">
                <option value="<?php echo $ta->semester ?>" selected><?php echo $ta->semester ?></option>
                <option>Ganjil</option>
                <option>Genap</option>
            </select>
        </div>
        <div class="form-group">
            <label>Status Mahasiswa</label>
            <select name="status" class="form-control">
                <option value="<?php echo $ta->status ?>" selected><?php echo $ta->status ?></option>
                <option>Aktif</option>
                <option>Nonaktif</option>
            </select>
        </div>
        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
            <?php echo anchor('admin/tahun_akademik', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
        </div>
    </form>
    <?php endforeach; ?>
</div>