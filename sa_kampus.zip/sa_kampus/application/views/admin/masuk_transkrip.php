<div class="container-fluid">

    <div class="alert alert-success">
        <i class="fas fa-university"></i> Form Masuk Transkrip Nilai
    </div>

    <form method="post" action="<?php echo base_url('admin/transkrip/aksi_buat_transkrip') ?>">
        <div class="form-group">
            <label>Nim</label>
            <input type="text" name="nim" class="form-control" placeholder="Masukkan NIM Mahasiswa">
            <?php echo form_error('nim','<div class="text-danger small ml-2">','</div>'); ?>
        </div>

        <button type="submit" class="btn btn-primary">Proses</button>
    </form>
</div>