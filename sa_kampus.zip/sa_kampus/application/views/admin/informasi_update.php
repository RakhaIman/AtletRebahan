<div class="container-fluid">

  <div class="alert alert-success" role="alert">
    <i class="fas fa-user-graduate"></i> Form Update Informasi
  </div>


  <?php foreach ($informasi as $info) : ?>
    <form method="post" action="<?php echo base_url('admin/informasi/aksi_update_informasi') ?>">

      <div class="form-group">
        <label>ICON</label>
        <input type="hidden" name="id_informasi" class="form-control" value="<?php echo $info->id_informasi ?>" required>
        <input type="text" name="icon" class="form-control" id="icon" value="<?php echo $info->icon ?>" required>
        <?php echo form_error('icon', '<div class="text-danger small ml-3">', '</div>') ?>
      </div>

      <div class="form-group">
        <label>Judul Informasi</label>
        <input type="text" name="judul_informasi" class="form-control" id="judul_informasi" value="<?php echo $info->judul_informasi ?>" required>
        <?php echo form_error('judul_informasi', '<div class="text-danger small ml-3">', '</div>') ?>
      </div>

      <div class="form-group">
        <label>Isi Informasi</label>
        <input type="text" name="isi_informasi" class="form-control" id="isi_informasi" value="<?php echo $info->isi_informasi ?>" required>
        <?php echo form_error('isi_informasi', '<div class="text-danger small ml-3">', '</div>') ?>
      </div>


      <div class="d-flex justify-content-between mt-4">
        <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
        <?php echo anchor('admin/dosen', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
      </div>

    <?php endforeach; ?>
    </form> <br>
</div>