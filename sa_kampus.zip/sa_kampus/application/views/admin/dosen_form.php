<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-user-graduate"></i> Form Tambah Dosen
    </div>

    <?php echo form_open_multipart('admin/dosen/aksi_tambah_dosen') ?>

    <div class="form-group">
        <label>NIDN</label>
        <input type="text" name="nidn" class="form-control" placeholder="Masukkan NIDN" required>
        <?php echo form_error('nidn', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label>Nama Dosen</label>
        <input type="text" name="nama_dosen" class="form-control" placeholder="Masukkan Nama Dosen" required>
        <?php echo form_error('nama_dosen', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label>Alamat</label>
        <input type="text" name="alamat" class="form-control" placeholder="Masukkan Alamat" required>
        <?php echo form_error('alamat', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" class="form-control" placeholder="Masukkan Email" required>
        <?php echo form_error('email', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label>Telepon</label>
        <input type="number" name="telepon" class="form-control" placeholder="Masukkan Nomor Telepon" required>
        <?php echo form_error('telepon', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label>Jenis Kelamin</label>
        <select name="jenis_kelamin" class="form-control" required>
            <option value="">--Pilih Jenis Kelamin--</option>
            <option value="Laki-laki">Laki-laki</option>
            <option value="Perempuan">Perempuan</option>
        </select>
        <?php echo form_error('jenis_kelamin', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label>Foto</label><br>
        <input type="file" name="foto" class="form-control-file">
    </div>

    <div class="d-flex justify-content-between mt-4">
        <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
        <?php echo anchor('admin/dosen', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
    </div>

    <?php echo form_close(); ?>
    <br>
</div>