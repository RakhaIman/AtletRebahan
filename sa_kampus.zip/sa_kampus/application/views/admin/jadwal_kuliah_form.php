<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-calendar-alt"></i> Form Tambah Jadwal Kuliah
    </div>

    <?php echo form_open_multipart('admin/jadwal_kuliah/aksi_tambah_jadwal'); ?>

    <div class="form-group">
        <label for="kode_matkul">Kode Mata Kuliah</label>
        <input type="text" name="kode_matkul" id="kode_matkul" class="form-control" required>
        <?php echo form_error('kode_matkul', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="nama_dosen">Nama Dosen</label>
        <select name="nama_dosen" id="nama_dosen" class="form-control" required>
            <option value="">-- Pilih Dosen --</option>
            <?php foreach ($dosen as $dsn) : ?>
                <option value="<?php echo $dsn->nama_dosen ?>"><?php echo $dsn->nama_dosen ?></option>
            <?php endforeach; ?>
        </select>
        <?php echo form_error('nama_dosen', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="hari">Hari</label>
        <select name="hari" id="hari" class="form-control" required>
            <option value="">-- Pilih Hari --</option>
            <option value="Senin">Senin</option>
            <option value="Selasa">Selasa</option>
            <option value="Rabu">Rabu</option>
            <option value="Kamis">Kamis</option>
            <option value="Jumat">Jumat</option>
            <option value="Sabtu">Sabtu</option>
            <option value="Minggu">Minggu</option>
        </select>
        <?php echo form_error('hari', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="jam_mulai">Jam Mulai</label>
        <input type="time" name="jam_mulai" id="jam_mulai" class="form-control" required>
        <?php echo form_error('jam_mulai', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="jam_selesai">Jam Selesai</label>
        <input type="time" name="jam_selesai" id="jam_selesai" class="form-control" required>
        <?php echo form_error('jam_selesai', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <div class="form-group">
        <label for="ruangan">Ruangan</label>
        <input type="text" name="ruangan" id="ruangan" class="form-control" required>
        <?php echo form_error('ruangan', '<div class="text-danger small">', '</div>'); ?>
    </div>

    <button type="submit" class="btn btn-primary">Simpan</button>
    <button type="reset" class="btn btn-danger">Reset</button>

    <?php echo form_close(); ?>

</div>