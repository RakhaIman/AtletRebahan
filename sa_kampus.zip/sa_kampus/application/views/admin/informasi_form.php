<div class="container-fluid">

  <div class="alert alert-success" role="alert">
    <i class="fas fa-user-graduate"></i> Form Tambah Data Informasi
  </div>

  <form method="post" action="<?php echo base_url('admin/informasi/aksi_tambah_informasi') ?>">
    <div class="form-group">
      <label>Icon</label>
      <input type="hidden" name="id_informasi" class="form-control">
      <input type="text" name="icon" class="form-control" placeholder="Masukkan Icon" required>
      <?php echo form_error('icon', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
      <label>Judul Informasi</label>
      <input type="text" name="judul_informasi" class="form-control" placeholder="Masukkan Judul Informasi" required>
      <?php echo form_error('judul_informasi', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
      <label>Isi Informasi</label>
      <textarea type="text" name="isi_informasi" class="form-control" rows="3" placeholder="Masukkan Isi Informasi" required></textarea>
      <?php echo form_error('isi_informasi', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="d-flex justify-content-between mt-4">
        <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
        <?php echo anchor('admin/informasi', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
    </div>

  </form>
</div>