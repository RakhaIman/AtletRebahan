<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-user-graduate"></i> Dosen
    </div>

    <?php echo $this->session->flashdata('pesan') ?>

    <?php echo anchor('admin/dosen/tambah_dosen', '<button class="btn btn-sm btn-primary 
        mb-3"><i class="fas fa-plus fa-sm"></i> Tambah Dosen</button>') ?>

    <table class="table table-bordered table-striped table-hover">
        <tr>
            <th>No</th>
            <th>NIDN</th>
            <th>Nama Dosen</th>
            <th>Alamat</th>
            <th colspan="3">Aksi</th>
        </tr>

        <?php $no = 1;
        foreach ($dosen as $ds) : ?>

            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $ds->nidn ?></td>
                <td><?php echo $ds->nama_dosen ?></td>
                <td><?php echo $ds->alamat ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/dosen/detail/' . $ds->nidn,
                                        '<div class="btn btn-sm btn-info"><i class="fa fa-eye"></div>'
                                    ) ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/dosen/update/' . $ds->nidn,
                                        '<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></div>'
                                    ) ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/dosen/delete/' . $ds->nidn,
                                        '<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></div>'
                                    ) ?></td>
            </tr>

        <?php endforeach; ?>
    </table>
</div>