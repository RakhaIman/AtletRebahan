<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-edit"></i> Form Edit Matakuliah
    </div>

    <?php foreach ($matkul as $mk) : ?>
        <form method="post" action="<?php echo base_url('admin/matkul/aksi_update') ?>">
            <div class="form-group">
                <label>Nama Mata Kuliah</label>
                <input type="hidden" name="kode_matkul" class="form-control"
                    value="<?php echo $mk->kode_matkul ?>">
                <input type="text" name="nama_matkul" class="form-control"
                    value="<?php echo $mk->nama_matkul ?>">
            </div>
            <div class="form-group">
                <label>SKS</label>
                <select name="sks" class="form-control">
                    <option><?php echo $mk->sks ?></option>
                    <option>2</option>
                    <option>4</option>
                </select>
            </div>
            <div class="form-group">
                <label>Semester</label>
                <select name="semester" class="form-control">
                    <option><?php echo $mk->semester ?></option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                </select>
            </div>
            <div class="form-group">
                <label>Program Studi</label>
                <select name="nama_prodi" class="form-control">
                    <option><?php echo $mk->nama_prodi ?></option>
                    <?php foreach ($prodi as $prd) : ?>
                        <option value="<?php echo $prd->nama_prodi; ?>"><?php echo $prd->nama_prodi; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
                <?php echo anchor('admin/matkul', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
            </div>
        </form>
    <?php endforeach; ?>
</div>