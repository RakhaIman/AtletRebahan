<div class="container-fluid">

<div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Form Edit Tentang Kampus
    </div>

    <?php foreach($tentang as $ttg) : ?>

    <form method="post" action="<?php echo base_url('admin/tentang_kampus/aksi_update') ?>">
        <div class="form-group">
            <label>Sejarah</label>
            <input type="hidden" name="id" value="<?php echo $ttg->id ?>" class="form-control">
            <input type="text" name="sejarah" class="form-control" value="<?php echo $ttg->sejarah ?>">
        </div>
        <div class="form-group">
            <label>Visi</label>
            <input type="text" name="visi" class="form-control" value="<?php echo $ttg->visi ?>">
        </div>

        <div class="form-group">
            <label>Visi</label>
            <input type="text" name="misi" class="form-control" value="<?php echo $ttg->misi ?>">
        </div>

        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
            <?php echo anchor('admin/tentang_kampus', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
        </div>
    </form>
    <?php endforeach; ?>
</div>