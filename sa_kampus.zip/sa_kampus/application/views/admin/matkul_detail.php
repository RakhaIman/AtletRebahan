<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Detail Matakuliah
    </div>

    <table class="table table-bordered table-striped table-hover">
        <thead class="thead-dark">
            <tr>
                <th>Informasi</th>
                <th>Detail</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detail as $dt) : ?>
            <tr>
                <th>Kode Matakuliah</th>
                <td><?php echo $dt->kode_matkul; ?></td>
            </tr>
            <tr>
                <th>Nama Matakuliah</th>
                <td><?php echo $dt->nama_matkul; ?></td>
            </tr>
            <tr>
                <th>SKS</th>
                <td><?php echo $dt->sks; ?></td>
            </tr>
            <tr>
                <th>Semester</th>
                <td><?php echo $dt->semester; ?></td>
            </tr>
            <tr>
                <th>Program Studi</th>
                <td><?php echo $dt->nama_prodi; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="text-center mt-4">
        <?php echo anchor('admin/matkul', '<div class="btn btn-danger btn-lg">Kembali</div>'); ?>
    </div>
</div>