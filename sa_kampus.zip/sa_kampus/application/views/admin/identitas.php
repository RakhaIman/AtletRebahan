<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Identitas Website
    </div>

    <?php echo $this->session->flashdata('pesan') ?>

        <table class="table table-bordered table-hover table-striped">
        <tr>
            <th>No</th>
            <th>Nama Website</th>
            <th>Alamat</th>
            <th>Email</th>
            <th>No Telepon</th>
            <th>Aksi</th>
        </tr>
        <?php
        $no = 1;

         foreach ($identitas as $idn) : ?>

         <tr>
            <td><?php echo $no++ ?></td>
            <td><?php  echo $idn->nama_website ?></td>
            <td><?php echo $idn->alamat ?></td>
            <td><?php echo $idn->email ?></td>
            <td><?php echo $idn->telepon ?></td>
            <td width="20px"><?php echo anchor(
                                        'admin/identitas/update/' . $idn->id,
                                        '<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></div>'
                                    ) ?></td>
         </tr>
         <?php  endforeach; ?>
    </table>
</div>