<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-user-graduate"></i> Form Update Dosen
    </div>

    <?php echo form_open_multipart('admin/dosen/aksi_update_dosen') ?>

    <?php foreach($dosen as $ds) : ?>
    
    <div class="form-group">
        <label for="nidn">NIDN</label>
        <input type="hidden" name="id_dosen" class="form-control" value="<?php echo $ds->id_dosen ?>" required>
        <input type="text" name="nidn" class="form-control" id="nidn" value="<?php echo $ds->nidn ?>" required>
        <?php echo form_error('nidn', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="nama_dosen">Nama Dosen</label>
        <input type="text" name="nama_dosen" class="form-control" id="nama_dosen" value="<?php echo $ds->nama_dosen ?>" required>
        <?php echo form_error('nama_dosen', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="alamat">Alamat</label>
        <input type="text" name="alamat" class="form-control" id="alamat" value="<?php echo $ds->alamat ?>" required>
        <?php echo form_error('alamat', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" name="email" class="form-control" id="email" value="<?php echo $ds->email ?>" required>
        <?php echo form_error('email', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="telepon">Telepon</label>
        <input type="number" name="telepon" class="form-control" id="telepon" value="<?php echo $ds->telepon ?>" required>
        <?php echo form_error('telepon', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="jenis_kelamin">Jenis Kelamin</label>
        <select name="jenis_kelamin" class="form-control" id="jenis_kelamin" required>
            <option value="Laki-laki" <?php echo ($ds->jenis_kelamin == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
            <option value="Perempuan" <?php echo ($ds->jenis_kelamin == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
        </select>
        <?php echo form_error('jenis_kelamin', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="foto">Foto</label><br>
        <img src="<?php echo base_url() . 'assets/uploads/' . $ds->foto ?>" alt="Foto Dosen" style="width: 100px; height: auto;"><br><br>
        <input type="file" name="userfile">
    </div>

    <div class="d-flex justify-content-between mt-4">
        <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
        <?php echo anchor('admin/dosen', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
    </div>

    <?php endforeach; ?>
    <?php echo form_close(); ?>
    <br>
</div> 