<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-calendar-alt"></i> Presensi
    </div>

    <?php echo $this->session->flashdata('pesan') ?>

    <?php echo anchor('admin/presensi/tambah_presensi', '<button class="btn btn-sm btn-primary 
        mb-3"><i class="fas fa-plus fa-sm"></i> Tambah Presensi Mahasiswa </button>') ?>


    <table class="table table-bordered table-striped table-hover">
    <thead>
            <tr>
                <th>No</th>
                <th>Nama Mahasiswa</th>
                <th>Tanggal Presensi</th>
                <th>Status Presensi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach ($presensi as $p) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $p->nama_lengkap; ?></td>
                    <td><?= date('d-m-Y', strtotime($p->tanggal_presensi)); ?></td>
                    <td>
                        <?php if ($p->status_presensi == 'Hadir') : ?>
                            <span class="badge badge-success"><?= $p->status_presensi; ?></span>
                        <?php elseif ($p->status_presensi == 'Tidak Hadir') : ?>
                            <span class="badge badge-danger"><?= $p->status_presensi; ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>