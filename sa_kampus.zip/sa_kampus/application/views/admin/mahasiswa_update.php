<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-user-graduate"></i> Form Update Mahasiswa
    </div>

    <?php echo form_open_multipart('admin/mahasiswa/aksi_update_mhs') ?>

    <?php foreach($mahasiswa as $mhs) : ?>
    
    <div class="form-group">
        <label for="nim">NIM</label>
        <input type="hidden" name="id" class="form-control" value="<?php echo $mhs->id ?>" required>
        <input type="text" name="nim" class="form-control" id="nim" value="<?php echo $mhs->nim ?>" required>
        <?php echo form_error('nim', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="nama_lengkap">Nama Mahasiswa</label>
        <input type="text" name="nama_lengkap" class="form-control" id="nama_lengkap" value="<?php echo $mhs->nama_lengkap ?>" required>
        <?php echo form_error('nama_lengkap', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="alamat">Alamat</label>
        <input type="text" name="alamat" class="form-control" id="alamat" value="<?php echo $mhs->alamat ?>" required>
        <?php echo form_error('alamat', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" name="email" class="form-control" id="email" value="<?php echo $mhs->email ?>" required>
        <?php echo form_error('email', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="telepon">Telepon</label>
        <input type="number" name="telepon" class="form-control" id="telepon" value="<?php echo $mhs->telepon ?>" required>
        <?php echo form_error('telepon', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="tempat_lahir">Tempat Lahir</label>
        <input type="text" name="tempat_lahir" class="form-control" id="tempat_lahir" value="<?php echo $mhs->tempat_lahir ?>" required>
        <?php echo form_error('tempat_lahir', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="tanggal_lahir">Tanggal Lahir</label>
        <input type="date" name="tanggal_lahir" class="form-control" id="tanggal_lahir" value="<?php echo $mhs->tanggal_lahir ?>" required>
        <?php echo form_error('tanggal_lahir', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="jenis_kelamin">Jenis Kelamin</label>
        <select name="jenis_kelamin" class="form-control" id="jenis_kelamin" required>
            <option value="Laki-laki" <?php echo ($mhs->jenis_kelamin == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
            <option value="Perempuan" <?php echo ($mhs->jenis_kelamin == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
        </select>
        <?php echo form_error('jenis_kelamin', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="nama_prodi">Program Studi</label>
        <select name="nama_prodi" class="form-control" id="nama_prodi" required>
            <?php foreach ($prodi as $prd) : ?>
                <option value="<?php echo $prd->nama_prodi ?>" <?php echo ($mhs->nama_prodi == $prd->nama_prodi) ? 'selected' : ''; ?>><?php echo $prd->nama_prodi ?></option>
            <?php endforeach; ?>
        </select>
        <?php echo form_error('nama_prodi', '<div class="text-danger small ml-3">', '</div>') ?>
    </div>

    <div class="form-group">
        <label for="foto">Foto</label><br>
        <img src="<?php echo base_url() . 'assets/uploads/' . $mhs->foto ?>" alt="Foto Mahasiswa" style="width: 100px; height: auto;"><br><br>
        <input type="file" name="userfile">
    </div>

    <div class="d-flex justify-content-between mt-4">
        <button type="submit" class="btn btn-primary btn-md"><i class="fas fa-save"></i> Simpan</button>
        <?php echo anchor('admin/mahasiswa', '<div class="btn btn-danger btn-md"><i class="fas fa-arrow-left"></i> Kembali</div>'); ?>
    </div>

    <?php endforeach; ?>
    <?php echo form_close(); ?>
    <br>
</div> 