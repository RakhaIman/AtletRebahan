<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-calendar"></i> Form Input Presensi
    </div>

    <form method="post" action="<?php echo base_url('admin/presensi/aksi_tambah_presensi') ?>">
        <div class="form-group">
            <label for="id_mahasiswa">Nama Mahasiswa</label>
            <select name="id_mahasiswa" id="id_mahasiswa" class="form-control">
                <?php foreach ($mahasiswa as $m) : ?>
                    <option value="<?php echo $m->id ?>"><?php echo $m->nama_lengkap ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="tanggal_presensi">Tanggal Presensi</label>
            <input type="date" name="tanggal_presensi" id="tanggal_presensi" class="form-control">
        </div>
        <div class="form-group">
            <label for="status_presensi">Status Presensi</label>
            <select name="status_presensi" id="status_presensi" class="form-control">
                <option value="Hadir">Hadir</option>
                <option value="Tidak Hadir">Tidak Hadir</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>