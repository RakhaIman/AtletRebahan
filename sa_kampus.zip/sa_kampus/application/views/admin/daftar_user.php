<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Daftar User
    </div>

    <?php echo $this->session->flashdata('pesan') ?>

    <?php echo anchor('admin/user/tambah_user', '<button class="btn btn-sm btn-primary 
        mb-3"><i class="fas fa-plus fa-sm"></i> Tambah User</button>') ?>

        <table class="table table-bordered table-hover table-striped">
        <tr>
            <th>No</th>
            <th>Username</th>
            <th>Email</th>
            <th>Level</th>
            <th>Blokir</th>
            <th colspan="2">Aksi</th>
        </tr>
        <?php
        $no = 1;

         foreach ($user as $u) : ?>

         <tr>
            <td><?php echo $no++ ?></td>
            <td><?php  echo $u->username ?></td>
            <td><?php echo $u->email ?></td>
            <td><?php echo $u->level ?></td>
            <td><?php echo $u->blokir ?></td>
            <td width="20px"><?php echo anchor(
                                        'admin/user/update/' . $u->id,
                                        '<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></div>'
                                    ) ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/user/delete/' . $u->id,
                                        '<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></div>'
                                    ) ?></td>
         </tr>
         <?php  endforeach; ?>
    </table>
</div>