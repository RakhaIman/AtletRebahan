<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-calendar-alt"></i> Jadwal Kuliah
    </div>

    <?php echo $this->session->flashdata('pesan') ?>

    <?php echo anchor('admin/jadwal_kuliah/tambah_jadwal', '<button class="btn btn-sm btn-primary 
        mb-3"><i class="fas fa-plus fa-sm"></i> Tambah Jadwal Kuliah</button>') ?>

    <table class="table table-bordered table-striped table-hover">
        <tr>
            <th>No</th>
            <th>Mata Kuliah</th>
            <th>Dosen</th>
            <th>Hari</th>
            <th>Jam Mulai</th>
            <th>Jam Selesai</th>
            <th>Ruangan</th>
            <th colspan="3">Aksi</th>
        </tr>

        <?php $no = 1;
        foreach ($jadwal_kuliah as $jk) : ?>

            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $jk->kode_matkul ?></td>
                <td><?php echo $jk->nama_dosen ?></td>
                <td><?php echo $jk->hari ?></td>
                <td><?php echo $jk->jam_mulai ?></td>
                <td><?php echo $jk->jam_selesai ?></td>
                <td><?php echo $jk->ruangan ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/jadwal_kuliah/detail/' . $jk->id,
                                        '<div class="btn btn-sm btn-info"><i class="fa fa-eye"></div>'
                                    ) ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/jadwal_kuliah/update/' . $jk->id,
                                        '<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></div>'
                                    ) ?></td>
                <td width="20px"><?php echo anchor(
                                        'admin/jadwal_kuliah/delete/' . $jk->id,
                                        '<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></div>'
                                    ) ?></td>
            </tr>

        <?php endforeach; ?>
    </table>
</div>