<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-plus"></i> Form Tambah Kartu Rencana Studi (KRS)
    </div>

    <form method="post" action="<?php echo base_url('admin/krs/aksi_tambah_krs')?>">
        <div class="form-group">
            <label>Tahun Akademik</label>
            <input type="hidden" name="id_ta" class="form-control" value="<?php echo $id_ta; ?>">
            <input type="hidden" name="id_krs" class="form-control" value="<?php echo $id_krs; ?>">
            <input type="text" name="thn_akad_smt" class="form-control" value="<?php echo $thn_akad_smt. '/' .$semester; ?>" readonly>
        </div>
        <div class="form-group">
            <label>NIM Mahasiswa</label>
            <input type="text" name="nim" class="form-control" value="<?php echo $nim; ?>" readonly>
        </div>
        <div class="form-group">
            <label>Matakuliah</label>
            <?php
                $query = $this->db->query('SELECT
                kode_matkul,nama_matkul FROM matkul');

                $dropdowns = $query->result();
                foreach($dropdowns as $dropdown){
                    $dropDowmList[$dropdown->kode_matkul] = $dropdown->nama_matkul;
                }

                echo form_dropdown('kode_matkul', $dropDowmList, $kode_matkul, 'class="form-control" id="kode_matkul"');
            ?>
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
        <?php echo anchor('admin/krs/aksi_krs','<div class="btn btn-danger"> Cancel </div>') ?>
    </form>
</div>