<?php
class Identitas extends CI_Controller{

    public function index()
    {
        $data['identitas'] = $this->identitas_model->tampil_data('identitas')->result();
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/identitas', $data);
        $this->load->view('template_admin/footer');
    }

    public function update($id)
    {
        $where = array('id' => $id);

        $data['identitas'] = $this->identitas_model->edit_data($where, 'identitas')->result();
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/identitas_update', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_update()
    {
        $id             = $this->input->post('id');
        $nama_website   = $this->input->post('nama_website');
        $alamat         = $this->input->post('alamat');
        $email          = $this->input->post('email');
        $telepon        = $this->input->post('telepon');

        $data = array(
            'nama_website'  => $nama_website,
            'alamat'        => $alamat,
            'email'         => $email,
            'telepon'       => $telepon,
        );

        $where = array(
            'id' => $id
        );

        $this->identitas_model->update_data($where,$data,'identitas');
        $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Identitas Berhasil Diupdate!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/identitas');
    }
}