<?php
class Transkrip extends CI_Controller
{

    public function index()
    {
        $data = array(
            'nim' => set_value('nim')
        );

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/masuk_transkrip', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_buat_transkrip()
    {
        $this->_rulesTranskrip();

        if ($this->form_validation->run() == FALSE) {
            $this->index();
        } else {
            $nim = $this->input->post('nim', TRUE);

            $this->db->select('*');
            $this->db->from('krs');
            $this->db->where('nim', $nim);
            $query = $this->db->get();

            foreach($query->result() as $value) {
                cekNilai($value->nim, $value->kode_matkul, $value->nilai);
            }

            $this->db->select('t.kode_matkul,m.nama_matkul,m.sks,t.nilai');
            $this->db->from('transkrip_nilai as t');
            $this->db->where('nim', $nim);
            $this->db->join('matkul as m', 'm.kode_matkul=t.kode_matkul');
            $transkrip = $this->db->get()->result();
            $mhs = $this->db->select('nama_lengkap, nama_prodi')
                ->from('mahasiswa')
                ->where(array('nim=>$nim'))
                ->get()->row();

            $prodi = $this->db->select('nama_prodi')
                ->from('prodi')
                ->where(array('mhs=>$mhs->nama_prodi'))
                ->get()->row()->nama_prodi;

            $data = array(
                'transkrip' => $transkrip,
                'nim' => $nim,
                'nama' => $mhs->nama_lengkap,
                'prodi' => $prodi,
            );
            $this->load->view('template_admin/header');
            $this->load->view('template_admin/sidebar');
            $this->load->view('admin/data_transkrip', $data);
            $this->load->view('template_admin/footer');
        }
    }

    public function _rulesTranskrip()
    {
        $this->form_validation->set_rules('nim', 'NIM', 'required',['required' => 'NIM Wajib Diisi!']);
    }
}
