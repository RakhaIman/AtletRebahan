<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Jadwal_kuliah extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('jadwal_kuliah_model');
        $this->load->model('dosen_model');
        $this->load->model('matkul_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['jadwal_kuliah'] = $this->jadwal_kuliah_model->tampil_data('jadwal_kuliah')->result();
        $data['dosen'] = $this->dosen_model->tampil_data('dosen')->result();
        $data['matkul'] = $this->matkul_model->tampil_data('matkul')->result();

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/jadwal_kuliah', $data);
        $this->load->view('template_admin/footer');
    }

    public function detail($id)
    {
        $data['detail'] = $this->jadwal_kuliah_model->ambil_id_jadwal($id);

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/jadwal_kuliah_detail', $data);
        $this->load->view('template_admin/footer');
    }

    public function tambah_jadwal()
    {
        $data['dosen'] = $this->dosen_model->tampil_data('dosen')->result();
        $data['matkul'] = $this->matkul_model->tampil_data('matkul')->result();

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/jadwal_kuliah_form', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_tambah_jadwal()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->tambah_jadwal();
        } else {
            $kode_matkul    = $this->input->post('kode_matkul');
            $nama_dosen     = $this->input->post('nama_dosen');
            $hari           = $this->input->post('hari');
            $jam_mulai      = $this->input->post('jam_mulai');
            $jam_selesai    = $this->input->post('jam_selesai');
            $ruangan        = $this->input->post('ruangan');

            $data = array(
                'kode_matkul'   => $kode_matkul,
                'nama_dosen'    => $nama_dosen,
                'hari'          => $hari,
                'jam_mulai'     => $jam_mulai,
                'jam_selesai'   => $jam_selesai,
                'ruangan'       => $ruangan,
            );

            $this->jadwal_kuliah_model->insert_data($data, 'jadwal_kuliah');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Jadwal Kuliah Berhasil Ditambahkan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/jadwal_kuliah');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('kode_matkul', 'kode_matkul', 'required', [
            'required' => 'Kode Mata Kuliah wajib diisi!'
        ]);
        $this->form_validation->set_rules('nama_dosen', 'nama_dosen', 'required', [
            'required' => 'Nama Dosen wajib diisi!'
        ]);
        $this->form_validation->set_rules('hari', 'hari', 'required', [
            'required' => 'Hari wajib di isi!'
        ]);
        $this->form_validation->set_rules('jam_mulai', 'jam_mulai', 'required', [
            'required' => 'Jam Mulai wajib diisi!'
        ]);
        $this->form_validation->set_rules('jam_selesai', 'jam_selesai', 'required', [
            'required' => 'Jam Selesai wajib diisi!'
        ]);
        $this->form_validation->set_rules('ruangan', 'ruangan', 'required', [
            'required' => 'Ruangan wajib diisi!'
        ]);
    }

    public function update($id)
    {
        $data['jadwal'] = $this->jadwal_kuliah_model->ambil_id_jadwal($id);
        $data['dosen'] = $this->dosen_model->tampil_data('dosen')->result();
        $data['matkul'] = $this->matkul_model->tampil_data('matkul')->result();

        // Pastikan data jadwal ditemukan
        if (empty($data['jadwal'])) {
            show_404(); // Tampilkan halaman 404 jika tidak ditemukan
        }

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/jadwal_kuliah_update', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_update_jadwal()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id')); // Menggunakan ID dari form
        } else {
            $id             = $this->input->post('id');
            $kode_matkul    = $this->input->post('kode_matkul');
            $nama_dosen     = $this->input->post('nama_dosen');
            $hari           = $this->input->post('hari');
            $jam_mulai      = $this->input->post('jam_mulai');
            $jam_selesai    = $this->input->post('jam_selesai');
            $ruangan        = $this->input->post('ruangan');

            $data = array(
                'kode_matkul'   => $kode_matkul,
                'nama_dosen'    => $nama_dosen,
                'hari'          => $hari,
                'jam_mulai'     => $jam_mulai,
                'jam_selesai'   => $jam_selesai,
                'ruangan'       => $ruangan,
            );

            $where = array('id' => $id);
            $this->jadwal_kuliah_model->update_data($where, $data, 'jadwal_kuliah');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Jadwal Kuliah Berhasil Diupdate!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/jadwal_kuliah');
        }
    }

    public function delete($id)
    {
        $where = array('id' => $id);
        $this->jadwal_kuliah_model->hapus_data($where, 'jadwal_kuliah');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger 
            alert-dismissible fade show" role="alert">Jadwal Kuliah Berhasil Dihapus!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/jadwal_kuliah');
    }
}
