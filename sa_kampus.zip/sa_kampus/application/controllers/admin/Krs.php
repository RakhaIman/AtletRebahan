<?php
class Krs extends CI_Controller{

    public function index()
    {
        $data = array(
            'nim' => set_value('nim'),
            'id_ta' => set_value('id_ta'),
        );
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/masuk_krs', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_krs()
    {
        $this->_rulesKrs();
        if($this->form_validation->run() == FALSE){
            $this->index();
        }else{
            $nim = $this->input->post('nim', TRUE);
            $thn_akad = $this->input->post('id_ta', TRUE);
        }
        if ($this->mahasiswa_model->get_data_by_id($nim)==null)
        {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger 
            alert-dismissible fade show" role="alert">Data Mahasiswa Tidak Ditemukan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/krs');
        }

        $dataKrs = array(
            'krs_data' => $this->baca_krs($nim,$thn_akad),
            'nim' => $nim,
            'id_ta' => $thn_akad,
            'tahun_akademik' => $this->ta_model->get_data_by_id($thn_akad)->tahun_akademik,
            'semester' => $this->ta_model->get_data_by_id($thn_akad)->semester == 'Ganjil'?"Ganjil":"Genap",
            'nama_lengkap' => $this->mahasiswa_model->get_data_by_id($nim)->nama_lengkap,
            'prodi' => $this->mahasiswa_model->get_data_by_id($nim)->nama_prodi,
        );

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/krs_list', $dataKrs);
        $this->load->view('template_admin/footer');
    }

    public function baca_krs($nim,$thn_akad)
    {
        $this->db->select('k.id_krs,k.kode_matkul,m.nama_matkul,m.sks');
        $this->db->from('krs as k');
        $this->db->where('k.nim', $nim);
        $this->db->where('k.id_ta', $thn_akad);
        $this->db->join('matkul as m', 'm.kode_matkul = k.kode_matkul');

        $krs = $this->db->get()->result();
        return $krs;
    }

    public function _rulesKrs()
    {
        $this->form_validation->set_rules('nim', 'nim', 'required');
        $this->form_validation->set_rules('id_ta', 'id_ta', 'required');
    }

    public function tambah_krs($nim, $thn_akad)
    {
        $data = array(
            'id_krs' => set_value('id_krs'),
            'id_ta' => $thn_akad,
            'thn_akad_smt' => $this->ta_model->get_data_by_id($thn_akad)->tahun_akademik,
            'semester' => $this->ta_model->get_data_by_id($thn_akad)->semester == 'Ganjil'?"Ganjil":"Genap",
            'nim' => $nim,
            'kode_matkul' => set_value('kode_matkul')
        );

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/krs_form', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_tambah_krs()
    {
        $this->_rules();

        if($this->form_validation->run() == FALSE){
            $this->tambah_krs($this->input->post('nim', TRUE),
            $this->input->post('id_ta', TRUE));
        }else{
            $nim = $this->input->post('nim',TRUE);
            $id_ta = $this->input->post('id_ta',TRUE);
            $kode_matkul = $this->input->post('kode_matkul',TRUE);

            $data = array(
                'id_ta' => $id_ta,
                'nim' => $nim,
                'kode_matkul' => $kode_matkul,
            );

            $this->krs_model->insert($data);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data KRS Berhasil Ditambahkan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/krs/index');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('id_ta', 'id_ta', 'required');
        $this->form_validation->set_rules('nim', 'nim', 'required');
        $this->form_validation->set_rules('kode_matkul', 'kode_matkul', 'required');
    }

    public function update ($id)
    { 
        $row = $this->krs_model->get_data_by_id($id);
        $th = $row->id_ta;

        if($row) {
            $data = array(
                    'id_krs'        => set_value('id_krs',$row->id_krs),
                    'id_ta'         => set_value('id_ta', $row->id_ta),
                    'nim'           => set_value('nim', $row->nim),
                    'kode_matkul'   => set_value('kode_matkul', $row->kode_matkul),
                    'thn_akad_smt'  => $this->ta_model->get_data_by_id($th)->tahun_akademik,
                    'semester'      => $this->ta_model->get_data_by_id($th)->semester==1?'ganjil':'genap',
            );

            $this->load->view('template_admin/header');
            $this->load->view('template_admin/sidebar');
            $this->load->view('admin/krs_update', $data);
            $this->load->view('template_admin/footer');
        }else{
            echo "Data Tidak Ada!";
        }
    }

    public function aksi_update()
    {
        $id_krs = $this->input->post('id_krs', TRUE);
        $nim = $this->input->post('nim', TRUE);
        $id_ta = $this->input->post('id_ta', TRUE);
        $kode_matkul = $this->input->post('kode_matkul', TRUE);

        $data = array(
            'id_krs'        => $id_krs,
            'id_ta'         => $id_ta,
            'nim'           => $nim,
            'kode_matkul'   => $this->input->post('kode_matkul',TRUE)
        );

        $this->krs_model->update($id_krs, $data);
        $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data KRS Berhasil Diupdate!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/krs/index');
    }

    public function delete($id)
    {
        $where = array('id_krs' => $id);
        $this->krs_model->hapus_data($where,'krs');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger 
            alert-dismissible fade show" role="alert">Data Krs Berhasil Dihapus!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/krs/index');
    }
}