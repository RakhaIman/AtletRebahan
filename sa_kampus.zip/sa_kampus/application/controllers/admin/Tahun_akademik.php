<?php
class Tahun_akademik extends CI_Controller{

    public function index()
    {
        $data['tahun_akademik'] = $this->ta_model->tampil_data('tahun_akademik')->result();
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/tahun_akademik', $data);
        $this->load->view('template_admin/footer');
    }

    public function tambah_tahun()
    {
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/ta_form');
        $this->load->view('template_admin/footer');
    }

    public function aksi_tambah_tahun()
    {
        $this->_rules();
        
        if($this->form_validation->run() == FALSE)
        {
            $this->tambah_tahun();
        } else {
            $tahun_akademik     = $this->input->post('tahun_akademik');
            $semester     = $this->input->post('semester');
            $status   = $this->input->post('status');

            $data = array(
                'tahun_akademik' => $tahun_akademik,
                'semester' => $semester,
                'status' => $status,
            );

            $this->ta_model->insert_data($data,'tahun_akademik');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Tahun Akademik Berhasil Ditambahkan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/tahun_akademik');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('tahun_akademik','tahun_akademik','required',[
            'required' => 'Tahun Akademik wajib diisi!'
        ]);
        $this->form_validation->set_rules('semester','semester','required',[
            'required' => 'Semester wajib diisi!'
        ]);
        $this->form_validation->set_rules('status','status','required',[
            'required' => 'Status wajib diisi!'
        ]);
    }

    public function update($id)
    {
        $where = array('id_ta' => $id);
        $data['tahun_akademik'] = $this->ta_model->edit_data($where,'tahun_akademik')->result();

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/ta_update',$data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_update()
    {
        $id = $this->input->post('id_ta');
        $tahun_akademik = $this->input->post('tahun_akademik');
        $semester = $this->input->post('semester');
        $status = $this->input->post('status');
        $data = array(
            'tahun_akademik' => $tahun_akademik,
            'semester' => $semester,
            'status' => $status,
        );

        $where = array('id_ta' => $id);

        $this->ta_model->update_data($where,$data,'tahun_akademik');
        $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Tahun Akademik Berhasil Diubah!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/tahun_akademik');
    }

    public function delete($id)
    {
        $where = array('id_ta' => $id);
        $this->prodi_model->hapus_data($where,'tahun_akademik');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger 
            alert-dismissible fade show" role="alert">Data Tahun Akademik Berhasil Dihapus!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/tahun_akademik');
    }
}