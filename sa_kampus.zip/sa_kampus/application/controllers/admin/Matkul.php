<?php

class Matkul extends CI_Controller
{

    public function index()
    {
        $data['matkul'] = $this->matkul_model->tampil_data('matkul')->result();

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/matkul', $data);
        $this->load->view('template_admin/footer');
    }

    public function tambah_matkul()
    {
        $data['prodi'] = $this->matkul_model->tampil_data('prodi')->result();

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/matkul_form', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_tambah_matkul()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->tambah_matkul();
        } else {
            $kode_matkul  = $this->input->post('kode_matkul');
            $nama_matkul  = $this->input->post('nama_matkul');
            $sks          = $this->input->post('sks');
            $semester     = $this->input->post('semester');
            $nama_prodi   = $this->input->post('nama_prodi');

            $data = array(
                'kode_matkul' => $kode_matkul,
                'nama_matkul' => $nama_matkul,
                'sks'         => $sks,
                'semester'    => $semester,
                'nama_prodi'  => $nama_prodi
            );

            $this->matkul_model->insert_data($data, 'matkul');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Matakuliah Berhasil Ditambahkan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/matkul');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('kode_matkul', 'kode_matkul', 'required', [
            'required' => 'Kode Matkul wajib diisi!'
        ]);
        $this->form_validation->set_rules('nama_matkul', 'nama_matkul', 'required', [
            'required' => 'Nama Prodi wajib diisi!'
        ]);
        $this->form_validation->set_rules('sks', 'sks', 'required', [
            'required' => 'SKS wajib diisi!'
        ]);
        $this->form_validation->set_rules('semester', 'semester', 'required', [
            'required' => 'Semester wajib diisi!'
        ]);
        $this->form_validation->set_rules('nama_prodi', 'nama_prodi', 'required', [
            'required' => 'Nama Prodi wajib diisi!'
        ]);
    }

    public function detail($kode)
    {
        $data['detail'] = $this->matkul_model->ambil_kode_matkul($kode);

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/matkul_detail', $data);
        $this->load->view('template_admin/footer');
    }

    public function update($id)
    {
        $where = array('kode_matkul' => $id);
        
        $data['matkul'] = $this->db->query("select * from matkul mk, prodi prd where 
        mk.nama_prodi = prd.nama_prodi and mk.kode_matkul='$id'")->result();

        $data['prodi'] = $this->matkul_model->tampil_data('prodi')->result();

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/matkul_update',$data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_update()
    {
        $id = $this->input->post('kode_matkul');
        $kode_matkul = $this->input->post('kode_matkul');
        $nama_matkul = $this->input->post('nama_matkul');
        $sks = $this->input->post('sks');
        $semester = $this->input->post('semester');
        $nama_prodi = $this->input->post('nama_prodi');
        
        $data = array(
            'kode_matkul' => $kode_matkul,
            'nama_matkul' => $nama_matkul,
            'sks' => $sks,
            'semester' => $semester,
            'nama_prodi' => $nama_prodi
        );

        $where = array(
            'kode_matkul' => $kode_matkul
        );

        $this->matkul_model->update_data($where,$data,'matkul');
        $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Matakuliah Berhasil Diupdate!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/matkul');
    }

    public function delete($id)
    {
        $where = array('kode_matkul' => $id);
        $this->matkul_model->hapus_data($where,'matkul');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger 
            alert-dismissible fade show" role="alert">Data Matakuliah Berhasil Dihapus!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/matkul');
    }
}
