<?php
class User extends CI_Controller
{

    public function index()
    {
        $data['user'] = $this->user_model->tampil_data('user')->result();
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/daftar_user', $data);
        $this->load->view('template_admin/footer');
    }

    public function tambah_user()
    {
        $data = array(
            'username' => set_value('username'),
            'password' => set_value('password'),
            'email' => set_value('email'),
            'level' => set_value('level'),
            'blokir' => set_value('blokir'),
        );
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/user_form', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_tambah_user()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->tambah_user();
        } else {
            $data = array(
                'username' => $this->input->post('username', TRUE),
                'password' => md5($this->input->post('password', TRUE)),
                'email' => $this->input->post('email', TRUE),
                'level' => $this->input->post('level', TRUE),
                'blokir' => $this->input->post('blokir', TRUE),
                'id_sessions' => md5($this->input->post('id_sessions', TRUE)),
            );

            $this->user_model->insert_data($data, 'user');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data user Berhasil Ditambahkan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/user');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('username', 'Username', 'required', [
            'required' => 'Username Wajib Diisi',
        ]);
        $this->form_validation->set_rules('password', 'Password', 'required', [
            'required' => 'Password Wajib Diisi',
        ]);
        $this->form_validation->set_rules('email', 'Email', 'required', [
            'required' => 'Email Wajib Diisi',
        ]);
        $this->form_validation->set_rules('level', 'Level', 'required', [
            'required' => 'Level Wajib Diisi',
        ]);
        $this->form_validation->set_rules('blokir', 'Blokir', 'required', [
            'required' => 'Blokir Wajib Diisi',
        ]);
    }

    public function update($id)
    {
        $where = array('id' => $id);

        $data['user'] = $this->user_model->edit_data($where, 'user')->result();
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/user_update', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_update()
    {
        $id             = $this->input->post('id');
        $username       = $this->input->post('username');
        $password       = $this->input->post('password');
        $email          = $this->input->post('email');
        $level          = $this->input->post('level');
        $blokir         = $this->input->post('blokir');
        $id_sessions    = $this->input->post('id_sessions');

        $data = array(
            'username'  => $username,
            'password'  => $password,
            'email'     => $email,
            'level'     => $level,
            'blokir'    => $blokir,
        );

        $where = array(
            'id' => $id
        );

        $this->user_model->update_data($where,$data,'user');
        $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data User Berhasil Diupdate!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/user');
    }

    public function delete($id)
    {
        $where = array('id' => $id);
        $this->user_model->hapus_data($where,'user');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger 
            alert-dismissible fade show" role="alert">Data User Berhasil Dihapus!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/user');
    }
}
