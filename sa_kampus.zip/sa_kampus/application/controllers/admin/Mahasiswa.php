<?php

class Mahasiswa extends CI_Controller
{

    public function index()
    {
        $data['mahasiswa'] = $this->mahasiswa_model->tampil_data('mahasiswa')->result();
        $data['prodi'] = $this->prodi_model->tampil_data('prodi')->result();

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/mahasiswa', $data);
        $this->load->view('template_admin/footer');
    }

    public function detail($id)
    {
        $data['detail'] = $this->mahasiswa_model->ambil_id_mahasiswa($id);

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/mahasiswa_detail', $data);
        $this->load->view('template_admin/footer');
    }

    public function tambah_mahasiswa()
    {
        $data['prodi'] = $this->mahasiswa_model->tampil_data('prodi')->result();
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/mahasiswa_form', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_tambah_mhs()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->tambah_mahasiswa();
        } else {
            $nim                = $this->input->post('nim');
            $nama_lengkap       = $this->input->post('nama_lengkap');
            $alamat             = $this->input->post('alamat');
            $email              = $this->input->post('email');
            $telepon            = $this->input->post('telepon');
            $tempat_lahir       = $this->input->post('tempat_lahir');
            $tanggal_lahir      = $this->input->post('tanggal_lahir');
            $jenis_kelamin      = $this->input->post('jenis_kelamin');
            $nama_prodi         = $this->input->post('nama_prodi');
            $foto               = $_FILES['foto'];

            if ($foto = '') {
            } else {
                $config['upload_path'] = './assets/uploads';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|tiff';

                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('foto')) {
                    echo "Upload Gagal";
                    die();
                } else {
                    $foto = $this->upload->data('file_name');
                }
            }

            $data = array(
                'nim'               => $nim,
                'nama_lengkap'      => $nama_lengkap,
                'alamat'            => $alamat,
                'email'             => $email,
                'telepon'           => $telepon,
                'tempat_lahir'      => $tempat_lahir,
                'tanggal_lahir'     => $tanggal_lahir,
                'jenis_kelamin'     => $jenis_kelamin,
                'nama_prodi'        => $nama_prodi,
                'foto'              => $foto,
            );

            $this->mahasiswa_model->insert_data($data, 'mahasiswa');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Mahasiswa Berhasil Ditambahkan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/mahasiswa');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('nim', 'nim', 'required', [
            'required' => 'NIM wajib diisi!'
        ]);
        $this->form_validation->set_rules('nama_lengkap', 'nama_lengkap', 'required', [
            'required' => 'Nama Lengkap wajib diisi!'
        ]);
        $this->form_validation->set_rules('alamat', 'alamat', 'required', [
            'required' => 'Alamat wajib diisi!'
        ]);
        $this->form_validation->set_rules('email', 'email', 'required', [
            'required' => 'Email wajib diisi!'
        ]);
        $this->form_validation->set_rules('telepon', 'telepon', 'required', [
            'required' => 'Nomor Telepon wajib diisi!'
        ]);
        $this->form_validation->set_rules('tempat_lahir', 'tempat_lahir', 'required', [
            'required' => 'Tempat Lahir wajib diisi!'
        ]);
        $this->form_validation->set_rules('tanggal_lahir', 'tanggal_lahir', 'required', [
            'required' => 'Tanggal Lahir wajib diisi!'
        ]);
        $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required', [
            'required' => 'Jenis Kelamin wajib diisi!'
        ]);
        $this->form_validation->set_rules('nama_prodi', 'nama_prodi', 'required', [
            'required' => 'Program Studi wajib diisi!'
        ]);
    }

    public function update($id)
    {
        $data['mahasiswa'] = $this->mahasiswa_model->ambil_id_mahasiswa($id);
        $data['prodi'] = $this->matkul_model->tampil_data('prodi')->result();

        // Pastikan data mahasiswa ditemukan
        if (empty($data['mahasiswa'])) {
            show_404(); // Tampilkan halaman 404 jika tidak ditemukan
        }

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/mahasiswa_update', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_update_mhs()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id')); // Menggunakan ID dari form
        } else {
            $id                 = $this->input->post('id');
            $nim                = $this->input->post('nim');
            $nama_lengkap       = $this->input->post('nama_lengkap');
            $alamat             = $this->input->post('alamat');
            $email              = $this->input->post('email');
            $telepon            = $this->input->post('telepon');
            $tempat_lahir       = $this->input->post('tempat_lahir');
            $tanggal_lahir      = $this->input->post('tanggal_lahir');
            $jenis_kelamin      = $this->input->post('jenis_kelamin');
            $nama_prodi         = $this->input->post('nama_prodi');
            $foto               = $_FILES['userfile']['name'];

            $data = array(
                'nim'               => $nim,
                'nama_lengkap'      => $nama_lengkap,
                'alamat'            => $alamat,
                'email'             => $email,
                'telepon'           => $telepon,
                'tempat_lahir'      => $tempat_lahir,
                'tanggal_lahir'     => $tanggal_lahir,
                'jenis_kelamin'     => $jenis_kelamin,
                'nama_prodi'        => $nama_prodi
            );

            // Cek jika foto diupload
            if ($foto) {
                $config['upload_path'] = './assets/uploads';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|tiff';

                $this->load->library('upload', $config);
                if ($this->upload->do_upload('userfile')) {
                    $userfile = $this->upload->data('file_name');
                    $data['foto'] = $userfile; // Tambahkan foto ke data
                } else {
                    // Jika upload gagal, ambil pesan kesalahan
                    $error = $this->upload->display_errors();
                    $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Upload Gagal: ' . $error . '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    redirect('admin/mahasiswa/update/' . $id); // Redirect kembali ke halaman update
                    return; // Hentikan eksekusi lebih lanjut
                }
            }

            $where = array('id' => $id);
            $this->mahasiswa_model->update_data($where, $data, 'mahasiswa');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Mahasiswa Berhasil Diupdate!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/mahasiswa');
        }
    }

    public function delete($id)
    {
        $where = array('id' => $id);
        $this->mahasiswa_model->hapus_data($where,'mahasiswa');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger 
            alert-dismissible fade show" role="alert">Data Mahasiswa Berhasil Dihapus!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/mahasiswa');
    }

    
}
