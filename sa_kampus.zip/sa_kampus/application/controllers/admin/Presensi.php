<?php
class Presensi extends CI_Controller
{

  public function index()
  {
    // $data['presensi'] = $this->presensi_model->tampil_data('presensi')->result();
    $data['presensi'] = $this->presensi_model->getAllPresensi();
    $this->load->view('template_admin/header');
    $this->load->view('template_admin/sidebar');
    $this->load->view('admin/presensi', $data);
    $this->load->view('template_admin/footer');
  }

  public function tambah_presensi()
  {
    $data['mahasiswa'] = $this->presensi_model->tampil_data('mahasiswa')->result();
    $this->load->view('template_admin/header');
    $this->load->view('template_admin/sidebar');
    $this->load->view('admin/presensi_form', $data);
    $this->load->view('template_admin/footer');
  }

  public function aksi_tambah_presensi()
{
    $this->_rules(); // Jika ada validasi, pastikan validasi berjalan dengan benar

    if ($this->form_validation->run() == FALSE) {
        $this->tambah_presensi(); // Jika validasi gagal, kembalikan ke form tambah presensi
    } else {
        $id_mahasiswa = $this->input->post('id_mahasiswa'); // Ambil data dari form
        $tanggal_presensi = $this->input->post('tanggal_presensi');
        $status_presensi = $this->input->post('status_presensi');

        $data = array(
            'id_mahasiswa' => $id_mahasiswa, // Sesuaikan dengan kolom di tabel presensi
            'tanggal_presensi' => $tanggal_presensi,
            'status_presensi' => $status_presensi
        );

        $this->presensi_model->insert_data($data, 'presensi'); // Simpan data ke tabel presensi
        $this->session->set_flashdata('pesan', '<div class="alert alert-success">Data Presensi Berhasil Ditambahkan!</div>');
        redirect('admin/presensi');
    }
}

  public function _rules()
  {
    $this->form_validation->set_rules('id_mahasiswa', 'id_mahasiswa', 'required', [
      'required' => 'Nama Mahasiswa wajib diisi!'
    ]);
    $this->form_validation->set_rules('tanggal_presensi', 'tanggal_presensi', 'required', [
      'required' => 'Tanggal Presensi wajib diisi!'
    ]);
    $this->form_validation->set_rules('status_presensi', 'status_presensi', 'required', [
      'required' => 'Status Presensi wajib diisi!'
    ]);
  }

  public function update($id)
  {
    $where = array('id_ta' => $id);
    $data['tahun_akademik'] = $this->ta_model->edit_data($where, 'tahun_akademik')->result();

    $this->load->view('template_admin/header');
    $this->load->view('template_admin/sidebar');
    $this->load->view('admin/ta_update', $data);
    $this->load->view('template_admin/footer');
  }

  public function aksi_update()
  {
    $id = $this->input->post('id_ta');
    $tahun_akademik = $this->input->post('tahun_akademik');
    $semester = $this->input->post('semester');
    $status = $this->input->post('status');
    $data = array(
      'tahun_akademik' => $tahun_akademik,
      'semester' => $semester,
      'status' => $status,
    );

    $where = array('id_ta' => $id);

    $this->ta_model->update_data($where, $data, 'tahun_akademik');
    $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Tahun Akademik Berhasil Diubah!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
    redirect('admin/tahun_akademik');
  }

  public function delete($id)
  {
    $where = array('id_ta' => $id);
    $this->prodi_model->hapus_data($where, 'tahun_akademik');
    $this->session->set_flashdata('pesan', '<div class="alert alert-danger 
            alert-dismissible fade show" role="alert">Data Tahun Akademik Berhasil Dihapus!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
    redirect('admin/tahun_akademik');
  }
}
