<?php
class Dosen extends CI_Controller
{

    public function index()
    {
        $data['dosen'] = $this->dosen_model->tampil_data('dosen')->result();
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/dosen', $data);
        $this->load->view('template_admin/footer');
    }

    public function detail($id)
    {
        $data['detail'] = $this->dosen_model->ambil_id_dosen($id);

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/dosen_detail', $data);
        $this->load->view('template_admin/footer');
    }

    public function tambah_dosen()
    {
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/dosen_form');
        $this->load->view('template_admin/footer');
    }

    public function aksi_tambah_dosen()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->tambah_dosen();
        } else {
            $nidn               = $this->input->post('nidn');
            $nama_dosen         = $this->input->post('nama_dosen');
            $alamat             = $this->input->post('alamat');
            $email              = $this->input->post('email');
            $telepon            = $this->input->post('telepon');
            $jenis_kelamin      = $this->input->post('jenis_kelamin');
            $foto               = $_FILES['foto'];

            if ($foto = '') {
            } else {
                $config['upload_path'] = './assets/uploads';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|tiff';

                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('foto')) {
                    echo "Upload Gagal";
                    die();
                } else {
                    $foto = $this->upload->data('file_name');
                }
            }

            $data = array(
                'nidn'            => $nidn,
                'nama_dosen'      => $nama_dosen,
                'alamat'          => $alamat,
                'email'           => $email,
                'telepon'         => $telepon,
                'jenis_kelamin'   => $jenis_kelamin,
                'foto'            => $foto,
            );

            $this->dosen_model->insert_data($data, 'dosen');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Dosen Berhasil Ditambahkan!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/dosen');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('nidn', 'nidn', 'required', [
            'required' => 'NIM wajib diisi!'
        ]);
        $this->form_validation->set_rules('nama_dosen', 'nama_dosen', 'required', [
            'required' => 'Nama Lengkap wajib diisi!'
        ]);
        $this->form_validation->set_rules('alamat', 'alamat', 'required', [
            'required' => 'Alamat wajib diisi!'
        ]);
        $this->form_validation->set_rules('email', 'email', 'required', [
            'required' => 'Email wajib diisi!'
        ]);
        $this->form_validation->set_rules('telepon', 'telepon', 'required', [
            'required' => 'Nomor Telepon wajib diisi!'
        ]);
        $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required', [
            'required' => 'Jenis Kelamin wajib diisi!'
        ]);
    }

    public function update($id)
    {
        $data['dosen'] = $this->dosen_model->ambil_id_dosen($id);

        // Pastikan data dosen ditemukan
        if (empty($data['dosen'])) {
            show_404(); // Tampilkan halaman 404 jika tidak ditemukan
        }

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/dosen_update', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_update_dosen()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_dosen')); // Menggunakan ID dari form
        } else {
            $id                 = $this->input->post('id_dosen');
            $nidn                = $this->input->post('nidn');
            $nama_dosen       = $this->input->post('nama_dosen');
            $alamat             = $this->input->post('alamat');
            $email              = $this->input->post('email');
            $telepon            = $this->input->post('telepon');
            $jenis_kelamin      = $this->input->post('jenis_kelamin');
            $foto               = $_FILES['userfile']['name'];

            $data = array(
                'nidn'               => $nidn,
                'nama_dosen'      => $nama_dosen,
                'alamat'            => $alamat,
                'email'             => $email,
                'telepon'           => $telepon,
                'jenis_kelamin'     => $jenis_kelamin,
            );

            // Cek jika foto diupload
            if ($foto) {
                $config['upload_path'] = './assets/uploads';
                $config['allowed_types'] = 'jpg|jpeg|png|gif|tiff';

                $this->load->library('upload', $config);
                if ($this->upload->do_upload('userfile')) {
                    $userfile = $this->upload->data('file_name');
                    $data['foto'] = $userfile; // Tambahkan foto ke data
                } else {
                    // Jika upload gagal, ambil pesan kesalahan
                    $error = $this->upload->display_errors();
                    $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Upload Gagal: ' . $error . '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    redirect('admin/dosen/update/' . $id); // Redirect kembali ke halaman update
                    return; // Hentikan eksekusi lebih lanjut
                }
            }

            $where = array('id_dosen' => $id);
            $this->dosen_model->update_data($where, $data, 'dosen');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success 
            alert-dismissible fade show" role="alert">Data Dosen Berhasil Diupdate!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
            redirect('admin/dosen');
        }
    }

    public function delete($id)
    {
        $where = array('nidn' => $id);
        $this->dosen_model->hapus_data($where, 'dosen');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger 
            alert-dismissible fade show" role="alert">Data Dosen Berhasil Dihapus!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span></button></div>');
        redirect('admin/dosen');
    }
}
