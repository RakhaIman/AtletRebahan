<?php
class Nilai extends CI_Controller
{

    public function index()
    {
        $data = array(
            'nim' => set_value('nim'),
            'id_ta' => set_value('id_ta'),
        );

        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/masuk_khs', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_nilai()
    {
        $this->_rulesKhs();

        if ($this->form_validation->run() == FALSE) {
            $this->index();
        } else {
            $nim = $this->input->post('nim', TRUE);
            $thn_akad = $this->input->post('id_ta', TRUE);

            $query  =   "SELECT krs.id_ta
                            ,krs.kode_matkul
                            ,matkul.nama_matkul
                            ,matkul.sks
                            ,krs.nilai
                        FROM
                            krs
                        INNER JOIN matkul
                        ON (krs.kode_matkul = matkul.kode_matkul)
                        WHERE krs.nim = $nim AND krs.id_ta = $thn_akad";
            $sql = $this->db->query($query)->result();

            $smt = $this->db->select('tahun_akademik, semester')->from('tahun_akademik')->where(array('id_ta' => $thn_akad))->get()->row();
            $query_str = "SELECT mahasiswa.nim
                                ,mahasiswa.nama_lengkap
                                ,prodi.nama_prodi
                            FROM
                                mahasiswa
                            INNER JOIN prodi
                            ON (mahasiswa.nama_prodi = prodi.nama_prodi);";

            $mhs = $this->db->query($query_str)->row();

            if ($smt->semester == 'Ganjil') {
                $tampilSemester = "Ganjil";
            } else {
                $tampilSemester = "Genap";
            }

            $data = array(
                'mhs_data' => $sql,
                'mhs_nim' => $nim,
                'mhs_nama' => $mhs->nama_lengkap,
                'mhs_prodi' => $mhs->nama_prodi,
                'thn_akad' => $smt->tahun_akademik . "(" . $tampilSemester . ")",
            );
            $this->load->view('template_admin/header');
            $this->load->view('template_admin/sidebar');
            $this->load->view('admin/khs', $data);
            $this->load->view('template_admin/footer');
        }
    }

    public function _rulesKhs()
    {
        $this->form_validation->set_rules('nim', 'nim', 'required');
        $this->form_validation->set_rules('id_ta', 'id_ta', 'required');
    }

    public function input_nilai()
    {
        $data = array(
            'kode_matkul' => set_value('kode_matkul'),
            'id_ta' => set_value('id_ta')
        );
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/input_nilai_form', $data);
        $this->load->view('template_admin/footer');
    }

    public function aksi_input_nilai()
    {
        $this->_rulesInputNilai();

        if ($this->form_validation->run() == FALSE) {
            $this->input_nilai();
        } else {
            $kode_matkul = $this->input->post('kode_matkul', TRUE);
            $id_ta = $this->input->post('id_ta', TRUE);

            $this->db->select('k.id_krs,k.nim,m.nama_lengkap,k.nilai, d.nama_matkul');
            $this->db->from('krs as k');
            $this->db->join('mahasiswa as m', 'm.nim = k.nim');
            $this->db->join('matkul as d', 'k.kode_matkul = d.kode_matkul');
            $this->db->where('k.id_ta', $id_ta);
            $this->db->where('k.kode_matkul', $kode_matkul);
            $query = $this->db->get()->result();

            $data = array(
                'list_nilai'    => $query,
                'kode_matkul'   => $kode_matkul,
                'id_ta'         => $id_ta
            );
            $this->load->view('template_admin/header');
            $this->load->view('template_admin/sidebar');
            $this->load->view('admin/nilai_form', $data);
            $this->load->view('template_admin/footer');
        }
    }

    public function _rulesInputNilai()
    {
        $this->form_validation->set_rules('kode_matkul', 'Kode Matakuliah', 'required');
        $this->form_validation->set_rules('id_ta', 'Tahun Akademik', 'required');
    }

    public function simpan_nilai()
    {
        $query = array();
        $id_krs = $_POST['id_krs'];
        $nilai = $_POST['nilai'];

        for ($i = 0; $i<sizeof($id_krs); $i++) 
        {
            $this->db->set('nilai', $nilai[$i])->where('id_krs', $id_krs[$i])->update('krs');
        }

        $data = array(
            'id_krs' => $id_krs
        );
        $this->load->view('template_admin/header');
        $this->load->view('template_admin/sidebar');
        $this->load->view('admin/daftar_nilai', $data);
        $this->load->view('template_admin/footer');
    }
}
