<?php 

class Landing_Page extends CI_Controller{

    public function index(){
        $this->load->model('dosen_model');
        $this->load->model('identitas_model');
        $this->load->model('informasi_model');
        $this->load->model('jadwal_kuliah_model');
        $this->load->model('jurusan_model');
        $this->load->model('krs_model');
        $this->load->model('login_model');
        $this->load->model('mahasiswa_model');
        $this->load->model('matkul_model');
        $this->load->model('presensi_model');
        $this->load->model('prodi_model');
        $this->load->model('ta_model');
        $this->load->model('tentang_model');
        $this->load->model('transkrip_model');
        $this->load->model('user_model');

        $data['identitas'] = $this->identitas_model->tampil_data('identitas')->result();
        $data['tentang'] = $this->tentang_model->tampil_data('tentang_kampus')->result();
        $data['informasi'] = $this->informasi_model->tampil_data('informasi')->result();
        $data['dosen'] = $this->dosen_model->tampil_data('dosen')->result();
        $data['jadwal_kuliah'] = $this->jadwal_kuliah_model->tampil_data('jadwal_kuliah')->result();
        $data['jurusan'] = $this->jurusan_model->tampil_data('jurusan')->result();
        $data['mahasiswa'] = $this->mahasiswa_model->tampil_data('mahasiswa')->result();
        $data['matkul'] = $this->matkul_model->tampil_data('matkul')->result();
        $data['presensi'] = $this->presensi_model->tampil_data('presensi')->result();
        $data['prodi'] = $this->prodi_model->tampil_data('prodi')->result();
        $data['ta'] = $this->ta_model->tampil_data('tahun_akademik')->result();
        $data['transkrip'] = $this->transkrip_model->tampil_data('transkrip');
        $data['user'] = $this->user_model->tampil_data('user')->result();
        $this->load->view('landing_page',$data);
    }
}

?>