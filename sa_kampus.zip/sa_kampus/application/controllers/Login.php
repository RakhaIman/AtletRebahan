<?php
class Login extends CI_Controller
{
  public function index()
  {
    $this->load->view('login');
  }

  public function cek_login()
  {
    $nim = $this->input->post('nim');
    $password = $this->input->post('password');

    $this->db->where('nim', $nim);
    $this->db->where('password', $password);
    $query = $this->db->get('mahasiswa');

    if ($query->num_rows() > 0) {
      $data = $query->row();
      $this->session->set_userdata('id', $data->id);
      $this->session->set_userdata('nim', $data->nim);
      $this->session->set_userdata('nama_lengkap', $data->nama_lengkap);
      redirect('mahasiswa');
    } else {
      $this->session->set_flashdata('error', 'NIM atau password salah');
      redirect('login');
    }
  }

  public function logout()
  {
    $this->session->sess_destroy();
    redirect('login');
  }
}
